package com.example.bus.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;



@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Bus {
	@Id
	private int busid;
	private String busname;
	private String source; 
	private String destination;
	private String fair;
	
}
