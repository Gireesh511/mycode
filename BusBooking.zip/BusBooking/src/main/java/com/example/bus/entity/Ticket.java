package com.example.bus.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Ticket {

	@Id
	private int bookingid;
	private String busname;
	private String username;
	private String mobileno;
	private String gender;
	private String source;
	private String destination;
	private int seateno;
	private String statu;
	

}
