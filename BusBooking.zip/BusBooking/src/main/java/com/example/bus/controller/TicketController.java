package com.example.bus.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.bus.entity.Bus;
import com.example.bus.entity.Ticket;
import com.example.bus.service.TicketService;

import io.swagger.v3.oas.annotations.Operation;

@Controller
@RequestMapping("/bus")
public class TicketController {
	
	@Autowired
	private TicketService service;
	
	//Booking Ticket
		@PostMapping("/bookticket")
		@Operation(description="Booking Bus Ticket")
		public ResponseEntity<?> Post(@RequestBody Ticket ticket)
		{
			ResponseEntity<?> responce ;
			responce = new ResponseEntity<>(service.bookticket(ticket),HttpStatus.OK);
			return responce;
			
		}
		//Getting All History
		@GetMapping("/history")
		@Operation(summary="getting all the clinic")
		public ResponseEntity<List<Ticket>> gethistory()
		{
			List<Ticket> history=service.gethistory();

			
			return new ResponseEntity<List<Ticket>>(history,HttpStatus.OK);
		}
		
		//cancel Ticket
		@DeleteMapping("/Delete/{bookingid}")
		@Operation(summary="Cancling Ticket")
		public ResponseEntity<Void>  cancleticket(@PathVariable(value ="bookingid") int bookingid) 
		{
		      service.cancleticket(bookingid);
			return new ResponseEntity<Void>(HttpStatus.ACCEPTED);

		}
		
		
		
		@GetMapping("/allbus")
		@Operation(summary="getting all Bus Details")
		public ResponseEntity<List<Bus>> getallbus()
		{
			List<Bus>Buss=service.getallbus();

			return new ResponseEntity<List<Bus>>(Buss,HttpStatus.OK);
		}
		
	

}
