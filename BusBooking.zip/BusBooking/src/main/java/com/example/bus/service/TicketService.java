package com.example.bus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bus.entity.Bus;
import com.example.bus.entity.Ticket;
import com.example.bus.repo.BusRepo;
import com.example.bus.repo.TicketRepo;

@Service
public class TicketService {
	
	@Autowired
	private TicketRepo ticketrepo;
	
	@Autowired
	private BusRepo busrepo;
	
	
	
public Ticket bookticket(Ticket ticket) {
		
		Ticket ti=null;
		
		ti=ticketrepo.save(ticket);	
		return ti;
	}


	public List<Ticket> gethistory() {
		
		List<Ticket> tick=ticketrepo.findAll();
		if(tick.isEmpty())
		{
			System.out.println("No History Avalible");
		}
		
		return tick;
	}
	

	
	public String cancleticket(int bookingid) {

		String ti=null;
		if(ticketrepo.equals(ti)) {
		System.out.print("clinic details does not found");
		}
		else {
			 ticketrepo.deleteById(bookingid);
			 ti = "deleted successfully";
		}
		return ti;
		
		
		
	}
	
	public List<Bus> getallbus() {
		List<Bus> bus=busrepo.findAll();
		if(bus.isEmpty())
		{
			System.out.println("No bus Avalible");
		}
		
		return bus;
	
	}



}
