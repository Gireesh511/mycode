package com.example.bus.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.bus.entity.Bus;


public interface BusRepo extends JpaRepository <Bus, Integer>  {


}
